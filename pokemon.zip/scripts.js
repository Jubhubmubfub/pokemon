$(document).ready(function(){

  for (var i =1;i<152;i++){
    $('div').append('<img src="http://pokeapi.co/media/img/'+i+'.png" alt="pokemon '+i+'">')

  }
})
